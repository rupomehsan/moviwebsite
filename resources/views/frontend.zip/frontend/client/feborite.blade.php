@extends('frontend.layouts.client.index')
@section('content')
<!-- video section start -->
<section class="video ptb-90 vidio-wrapper">
    <div class="container">
       
    </div>
</section><!-- video section end -->
  <div class="container" style="margin-top:50px;">
    <h3 class="mb-20">Feborite</h3>
        <div class="row mb-50">
            <div class="col-6 col-sm-6 col-md-6 col-lg-3">
                <div class="card-sl">
                    <div class="card-image">
                         <span> <i class="fa fa-heart rcolor"></i></a> </span>
                        <img
                            src="{{asset('assets/img/Rectangle 467.png')}}" />
                              <a class="card-action" href="#"><i class="fa fa-play" aria-hidden="true"></i></a>
                    </div>

                  
                    <h4 class="ptb-20 pb-2">Happier</h4>
                    <p>ED Shreen</p>
                 
                </div>
            </div>
           <div class="col-6 col-sm-6 col-md-6 col-lg-3">
                <div class="card-sl">
                    <div class="card-image">
                         <span> <i class="fa fa-heart rcolor"></i></a> </span>
                        <img
                            src="{{asset('assets/img/Rectangle 468.png')}}" />
                              <a class="card-action" href="#"><i class="fa fa-play" aria-hidden="true"></i></a>
                    </div>

                  
                    <h4 class="ptb-20 pb-2">Happier</h4>
                    <p>ED Shreen</p>
                 
                </div>
            </div>
           <div class="col-6 col-sm-6 col-md-6 col-lg-3">
                <div class="card-sl">
                    <div class="card-image">
                         <span> <i class="fa fa-heart rcolor"></i></a> </span>
                        <img
                            src="{{asset('assets/img/Rectangle 478.png')}}" />
                              <a class="card-action" href="#"><i class="fa fa-play" aria-hidden="true"></i></a>
                    </div>

                  
                    <h4 class="ptb-20 pb-2">Happier</h4>
                    <p>ED Shreen</p>
                 
                </div>
            </div>
            <div class="col-6 col-sm-6 col-md-6 col-lg-3">
                <div class="card-sl">
                    <div class="card-image">
                         <span> <i class="fa fa-heart rcolor"></i></a> </span>
                        <img
                            src="{{asset('assets/img/Rectangle 467.png')}}" />
                              <a class="card-action" href="#"><i class="fa fa-play" aria-hidden="true"></i></a>
                    </div>

                  
                    <h4 class="ptb-20 pb-2">Happier</h4>
                    <p>ED Shreen</p>
                 
                </div>
            </div>
            
        </div>  
        <div class="row mb-50">
            <div class="col-6 col-sm-6 col-md-6 col-lg-3">
                <div class="card-sl">
                    <div class="card-image">
                         <span> <i class="fa fa-heart"></i></a> </span>
                        <img
                            src="{{asset('assets/img/Rectangle 468.png')}}" />
                              <a class="card-action" href="#"><i class="fa fa-play" aria-hidden="true"></i></a>
                    </div>

                  
                    <h4 class="ptb-20 pb-2">Happier</h4>
                    <p>ED Shreen</p>
                 
                </div>
            </div>
            <div class="col-6 col-sm-6 col-md-6 col-lg-3">
                <div class="card-sl">
                    <div class="card-image">
                         <span> <i class="fa fa-heart"></i></a> </span>
                        <img
                            src="https://images.pexels.com/photos/1149831/pexels-photo-1149831.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" />
                              <a class="card-action" href="#"><i class="fa fa-play" aria-hidden="true"></i></a>
                    </div>

                  
                    <h4 class="ptb-20 pb-2">Happier</h4>
                    <p>ED Shreen</p>
                 
                </div>
            </div>
            <div class="col-6 col-sm-6 col-md-6 col-lg-3">
                <div class="card-sl">
                    <div class="card-image">
                         <span> <i class="fa fa-heart"></i></a> </span>
                        <img
                            src="https://images.pexels.com/photos/1149831/pexels-photo-1149831.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" />
                              <a class="card-action" href="#"><i class="fa fa-play" aria-hidden="true"></i></a>
                    </div>

                  
                    <h4 class="ptb-20 pb-2">Happier</h4>
                    <p>ED Shreen</p>
                 
                </div>
            </div>
            <div class="col-6 col-sm-6 col-md-6 col-lg-3">
                <div class="card-sl">
                    <div class="card-image">
                         <span> <i class="fa fa-heart"></i></a> </span>
                        <img
                            src="{{asset('assets/img/Rectangle 478.png')}}" />
                              <a class="card-action" href="#"><i class="fa fa-play" aria-hidden="true"></i></a>
                    </div>

                  
                    <h4 class="ptb-20 pb-2">Happier</h4>
                    <p>ED Shreen</p>
                 
                </div>
            </div>
            
        </div>  
 </div>  
@endsection
