@include('frontend.partials.client.header')
@yield('content')
@include('frontend.partials.client.footer')
